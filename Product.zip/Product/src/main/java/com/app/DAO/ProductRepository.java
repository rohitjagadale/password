package com.app.DAO;

//ProductRepository.java

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Product;

import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {
 Optional<Product> findByProductCode(String productCode);
}

