// ProductServiceImpl.java
package com.app.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.DAO.ProductRepository;
import com.app.entities.Product;

import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product createProduct(Product product) {
        // Check if the product with the given product code already exists
        Optional<Product> existingProduct = productRepository.findByProductCode(product.getProductCode());
        if (existingProduct.isPresent()) {
            // Product with the same code already exists, throw an exception or handle accordingly
            throw new RuntimeException("Product with the given product code already exists");
        }

        // Save the new product
        return productRepository.save(product);
    }

    @Override
    public Product getProductById(Long productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    @Override
    public Product getProductByCode(String productCode) {
        return productRepository.findByProductCode(productCode)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }
}
