// ProductService.java
package com.app.service;

import com.app.entities.Product;

public interface ProductService {
    Product createProduct(Product product);

    Product getProductById(Long productId);

    Product getProductByCode(String productCode);
}
