// Product.java
package com.app.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "products")
@Getter
@Setter
public class Product {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 @NotBlank(message = "Name cannot be blank")
 private String name;

 @NotBlank(message = "Product Code cannot be blank")
 @Column(unique = true)
 private String productCode;

 @NotNull(message = "Date of Manufacturing cannot be null")
 private LocalDate dateOfManufacturing;

 @Enumerated(EnumType.STRING)
 private Category category;
}
