package com.app.entities;


public enum Category {
 FASHION,
 ELECTRONICS
}
