http://localhost:8080/api/products

http://localhost:8080/api/products/1


http://localhost:8080/api/products/byCode/LT123


{
  "name": "Laptop",
  "productCode": "LT123",
  "dateOfManufacturing": "2023-01-20",
  "category": "ELECTRONICS"
}
