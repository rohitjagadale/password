package com.app.DAO;



import java.util.List;

public interface Review {
 List<Review> getAllReviews();

 Review getReviewById(Long reviewId);

 Review addReview(Review review);

 Review updateReview(Long reviewId, Review updatedReview);

 void deleteReview(Long reviewId);
}
