package com.app.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.DAO.Review;
import com.app.DAO.ReviewRepository;

@Service
public class ReviewServiceImpl implements ReviewService {

 @Autowired
 private ReviewRepository reviewRepository;

 @Override
 public List<Review> getAllReviews() {
     return reviewRepository.findAll();
 }

 @Override
 public Review getReviewById(Long reviewId) {
     return reviewRepository.findById(reviewId)
             .orElseThrow(() -> new RuntimeException("Review not found"));
 }

 @Override
 public Review addReview(Review review) {
     // Add logic to check if the user and movie exist
     return reviewRepository.save(review);
 }

 @Override
 public Review updateReview(Long reviewId, Review updatedReview) {
     Review existingReview = getReviewById(reviewId);
     // Update existingReview with values from updatedReview
     return reviewRepository.save(existingReview);
 }

 @Override
 public void deleteReview(Long reviewId) {
     reviewRepository.deleteById(reviewId);
 }
}
