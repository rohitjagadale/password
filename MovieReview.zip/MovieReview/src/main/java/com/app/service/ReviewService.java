package com.app.service;



import java.util.List;

import com.app.DAO.Review;

public interface ReviewService {
 List<Review> getAllReviews();

 Review getReviewById(Long reviewId);

 Review addReview(Review review);

 Review updateReview(Long reviewId, Review updatedReview);

 void deleteReview(Long reviewId);
}
