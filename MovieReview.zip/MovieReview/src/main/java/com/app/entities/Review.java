package com.app.entities;



import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Getter
@Setter
@Entity
public class Review {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 private String reviewContents;
 private int rating;

 @ManyToOne
 private User user;

 @ManyToOne
 private Movie movie;
}
