package com.app.entities;

public enum EmploymentType {
	FULL_TIME, PART_TIME, CONTRACT
}
