package com.app.customExceptionHandling;

@SuppressWarnings("serial")
public class ResourceNotFoundCustomException extends RuntimeException {

	public ResourceNotFoundCustomException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
