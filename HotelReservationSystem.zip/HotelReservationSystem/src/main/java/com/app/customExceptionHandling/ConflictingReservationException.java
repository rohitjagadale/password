package com.app.customExceptionHandling;


@SuppressWarnings("serial")
public class ConflictingReservationException extends RuntimeException {

    public ConflictingReservationException(String message) {
        super(message);
    }
}
