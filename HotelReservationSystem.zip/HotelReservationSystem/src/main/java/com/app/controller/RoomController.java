package com.app.controller;


import com.app.dto.RoomDTO;
import com.app.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/rooms")
public class RoomController {

    private final RoomService roomService;

    @GetMapping
    public ResponseEntity<List<RoomDTO>> getAvailableRooms() {
        List<RoomDTO> availableRooms = roomService.getAvailableRooms();
        return ResponseEntity.ok(availableRooms);
    }
}
