package com.app.customCentralizedExceptionalHandling;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.app.customExceptionHandling.ConflictingReservationException;

@RestControllerAdvice
public class CentralizedExceptionHandling {

    @ExceptionHandler(ConflictingReservationException.class)
    public ResponseEntity<String> handleConflictingReservationException(ConflictingReservationException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
    }
}
