package com.app.Entity;


public enum RoomType {
    SINGLE,
    DOUBLE,
    SUITE
}
