package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.Entity.RoomEntity;

import java.util.List;

public interface RoomRepository extends JpaRepository<RoomEntity, Long> {
    List<RoomEntity> findByAvailability(boolean availability);
}
