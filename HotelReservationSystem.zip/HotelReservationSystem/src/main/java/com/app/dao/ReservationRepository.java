package com.app.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.app.Entity.ReservationEntity;

import java.util.Date;
import java.util.Optional;

public interface ReservationRepository extends JpaRepository<ReservationEntity, Long> {
    Optional<ReservationEntity> findByRoomIdAndCheckInDate(Long roomId, Date checkInDate);
}
