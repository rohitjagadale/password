package com.app.dto;

import lombok.Data;

import java.util.Date;

@Data
public class ReservationDTO {

    private Long reservationId;

    private String guestName;

    private Date checkInDate;

    private Long roomId;

    private double totalPrice;
}
