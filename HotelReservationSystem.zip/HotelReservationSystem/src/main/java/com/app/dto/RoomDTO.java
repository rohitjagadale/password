package com.app.dto;


import lombok.Data;

@Data
public class RoomDTO {

    private Long roomId;

    private String roomNumber;

    private String type;

    private double price;

    private boolean availability;
}
