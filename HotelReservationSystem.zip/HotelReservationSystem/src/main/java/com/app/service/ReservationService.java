package com.app.service;



import com.app.dto.ReservationDTO;

public interface ReservationService {
    ReservationDTO createReservation(ReservationDTO reservationDTO);
    void cancelReservation(Long reservationId);
}
