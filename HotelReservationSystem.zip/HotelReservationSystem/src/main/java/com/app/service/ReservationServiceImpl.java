package com.app.service;


import com.app.Entity.ReservationEntity;
import com.app.customExceptionHandling.ConflictingReservationException;
import com.app.dao.ReservationRepository;
import com.app.dao.RoomRepository;
import com.app.dto.ReservationDTO;


import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
@RequiredArgsConstructor
public class ReservationServiceImpl implements ReservationService {

    private final ReservationRepository reservationRepository;
    private final RoomRepository roomRepository;
    private final ModelMapper modelMapper;

    @Override
    public ReservationDTO createReservation(ReservationDTO reservationDTO) {
        checkForConflictingReservation(reservationDTO);

        ReservationEntity reservationEntity = modelMapper.map(reservationDTO, ReservationEntity.class);
        ReservationEntity savedEntity = reservationRepository.save(reservationEntity);

        return modelMapper.map(savedEntity, ReservationDTO.class);
    }

    @Override
    public void cancelReservation(Long reservationId) {
        reservationRepository.deleteById(reservationId);
    }

    private void checkForConflictingReservation(ReservationDTO reservationDTO) {
        Long roomId = reservationDTO.getRoomId();
        Date checkInDate = reservationDTO.getCheckInDate();

        roomRepository.findById(roomId).ifPresent(roomEntity -> {
            reservationRepository.findByRoomIdAndCheckInDate(roomId, checkInDate).ifPresent(existingReservation -> {
                throw new ConflictingReservationException("Sorry ! This Room Is already Booked For same Date and Time");
            });
        });
    }
}
