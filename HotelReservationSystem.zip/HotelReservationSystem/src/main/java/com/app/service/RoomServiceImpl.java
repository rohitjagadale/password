package com.app.service;


import com.app.Entity.RoomEntity;
import com.app.dao.RoomRepository;
import com.app.dto.RoomDTO;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;
    private final ModelMapper modelMapper;

    @Override
    public List<RoomDTO> getAvailableRooms() {
        List<RoomEntity> availableRooms = roomRepository.findByAvailability(true);
        return availableRooms.stream()
                .map(roomEntity -> modelMapper.map(roomEntity, RoomDTO.class))
                .collect(Collectors.toList());
    }
}
