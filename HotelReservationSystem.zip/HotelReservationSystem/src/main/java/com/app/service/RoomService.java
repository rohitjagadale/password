package com.app.service;


import com.app.dto.RoomDTO;

import java.util.List;

public interface RoomService {
    List<RoomDTO> getAvailableRooms();
}

