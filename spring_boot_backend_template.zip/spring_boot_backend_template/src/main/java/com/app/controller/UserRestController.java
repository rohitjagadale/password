package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.User;
import com.app.service.IUserService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/users")

public class UserRestController {

	@Autowired
	private IUserService userService;
	
@GetMapping
public List<User>fetchAllUsers(){
	return userService.getAllUser();
}

//@PostMapping
//public User addNewUserDdeatils(@RequestBody User transientUser) {
//	return userService.addUser(transientUser);
//}

@PostMapping
public ResponseEntity<?> addNewUserDdeatils(@RequestBody User transientUser) {
	return new ResponseEntity<>(userService.addUser(transientUser),HttpStatus.CREATED);
}

}
