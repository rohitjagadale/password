package com.app.service;



import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.AppointmentDAO;
import com.app.dto.ApiResponse;
import com.app.entities.Appointment;

@Service
public class AppointmentServiceImpl implements AppointmentService {

 @Autowired
 private AppointmentDAO appointmentDAO;

 @Autowired
 private Validator validator;

 @Override
 public ApiResponse createAppointment(Appointment appointment) {
     // Validate using Spring's validation framework
     Set<ConstraintViolation<Appointment>> violations = validator.validate(appointment);
     if (!violations.isEmpty()) {
         String errorMessage = violations.stream()
                 .map(ConstraintViolation::getMessage)
                 .collect(Collectors.joining(", "));
         return new ApiResponse(errorMessage);
     }

     // Validate appointment date
     if (appointment.getDateTime() == null || appointment.getDateTime().isBefore(LocalDateTime.now())) {
         return new ApiResponse("Invalid appointment date. It must be in the future.");
     }

     // Validate conflicting appointments
     List<Appointment> conflictingAppointments = appointmentDAO.findByDateTimeAfterAndPatientName(appointment.getDateTime(), appointment.getPatientName());
     if (!conflictingAppointments.isEmpty()) {
         return new ApiResponse("Appointment scheduling failed. Conflicting appointments exist.");
     }

     appointmentDAO.save(appointment);
     return new ApiResponse("Appointment scheduled successfully!");
 }

 @Override
 public List<Appointment> getUpcomingAppointments(String patientName) {
     LocalDateTime now = LocalDateTime.now();
     return appointmentDAO.findByDateTimeAfterAndPatientName(now, patientName);
 }

 @Override
 public ApiResponse cancelAppointment(Long appointmentId) {
     try {
         Appointment appointment = appointmentDAO.findById(appointmentId)
                 .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with ID: " + appointmentId));
         appointmentDAO.deleteById(appointmentId);
         return new ApiResponse("Appointment canceled successfully!");
     } catch (ResourceNotFoundException ex) {
         throw ex; // Re-throw the custom exception
     } catch (Exception ex) {
         return new ApiResponse("Error canceling appointment. Please try again.");
     }
 }
}
