package com.app.service;



import com.app.dto.ApiResponse;
import com.app.entities.Appointment;

import java.util.List;

public interface AppointmentService {

 ApiResponse createAppointment(Appointment appointment);

 List<Appointment> getUpcomingAppointments(String patientName);

 ApiResponse cancelAppointment(Long appointmentId);
}
