package com.app.controller;



import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.ApiResponse;
import com.app.entities.Appointment;
  // Import statement for ResourceNotFoundException
import com.app.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

 @Autowired
 private AppointmentService appointmentService;

 @PostMapping
 public ApiResponse createAppointment(@Valid @RequestBody Appointment appointment, BindingResult bindingResult) {
     if (bindingResult.hasErrors()) {
         return handleValidationErrors(bindingResult);
     }

     return appointmentService.createAppointment(appointment);
 }

 @GetMapping("/{patientName}/upcoming")
 public List<Appointment> getUpcomingAppointments(@PathVariable String patientName) {
     return appointmentService.getUpcomingAppointments(patientName);
 }

 @DeleteMapping("/{appointmentId}")
 public ApiResponse cancelAppointment(@PathVariable Long appointmentId) {
     try {
         return appointmentService.cancelAppointment(appointmentId);
     } catch (ResourceNotFoundException ex) {
         return handleException(ex, HttpStatus.NOT_FOUND);
     } catch (Exception ex) {
         return handleException(ex, HttpStatus.INTERNAL_SERVER_ERROR);
     }
 }

 // Helper method to handle validation errors
 private ApiResponse handleValidationErrors(BindingResult bindingResult) {
     Map<String, String> errors = new HashMap<>();
     for (FieldError error : bindingResult.getFieldErrors()) {
         errors.put(error.getField(), error.getDefaultMessage());
     }
     return new ApiResponse("Validation failed", HttpStatus.BAD_REQUEST, errors);
 }

 // Helper method to handle exceptions
 private ApiResponse handleException(Exception ex, HttpStatus status) {
     return new ApiResponse(ex.getMessage(), status);
 }
}

