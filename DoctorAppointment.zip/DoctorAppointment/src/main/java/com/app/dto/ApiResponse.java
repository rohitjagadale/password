package com.app.dto;



import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;
import java.util.Map;

public class ApiResponse {
    private String message;
    private LocalDateTime timestamp;
    private Map<String, String> errors;
    private HttpStatus status;

    public ApiResponse(String message) {
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    public ApiResponse(String message, HttpStatus status) {
        this.message = message;
        this.timestamp = LocalDateTime.now();
        this.status = status;
    }

    public ApiResponse(String message, HttpStatus status, Map<String, String> errors) {
        this.message = message;
        this.timestamp = LocalDateTime.now();
        this.status = status;
        this.errors = errors;
    }

    public String getMessage() {
        return message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public Map<String, String> getErrors() {
        return errors;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
