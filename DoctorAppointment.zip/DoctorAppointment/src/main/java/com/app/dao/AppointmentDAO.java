package com.app.dao;



import com.app.entities.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface AppointmentDAO extends JpaRepository<Appointment, Long> {

 List<Appointment> findByDateTimeAfterAndPatientName(LocalDateTime dateTime, String patientName);
}
