package com.app.entities;



import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotEmpty;
import java.time.LocalDateTime;

@Entity
@Table(name = "appointments")
@Getter
@Setter
public class Appointment {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 @NotEmpty(message = "Patient name cannot be empty")
 private String patientName;

 @NotEmpty(message = "Doctor name cannot be empty")
 private String doctor;

 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
 @FutureOrPresent(message = "Appointment date must be in the future or present")
 private LocalDateTime dateTime;

 // Add any other fields as needed

 // Constructors, getters, setters
}
