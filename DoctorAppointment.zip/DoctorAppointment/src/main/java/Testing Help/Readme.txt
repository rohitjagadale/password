Post     http://localhost:8080/appointments

{
  "patientName": "Anuj",
  "doctor": "Dr. Smith",
  "dateTime": "2024-06-01T10:00:00"
}

http://localhost:8080/appointments/Anuj/upcoming




http://localhost:8080/appointments/2