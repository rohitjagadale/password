http://localhost:8080/admission/courses/1/students/3

http://localhost:8080/admission/courses/1/fees/2001

http://localhost:8080/admission/students

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "course": {
    "id": 1  // Replace with the actual course ID to which the student is being admitted
  },
  "scoreObtained": 80.5
}



http://localhost:8080/admission/courses


{
  "title": "Introduction to Spring Boot",
  "startDate": "2024-02-01",
  "endDate": "2024-04-30",
  "fees": 1500.0,
  "minScore": 80
}
