package com.app.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.app.entities.Student;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class ApiResponse {
    private String message;
    private LocalDateTime timeStamp;
    private List<Student> students;

    public ApiResponse(String message) {
        this.message = message;
        this.timeStamp = LocalDateTime.now();
    }

    public ApiResponse(List<Student> students) {
        this.students = students;
        this.timeStamp = LocalDateTime.now();
    }
}
