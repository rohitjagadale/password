package com.app.service;

import com.app.entities.Course;

public interface CourseService {
    String launchNewCourse(Course course);

    String updateCourseFees(Long courseId, double updatedFees);
}
