package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.StudentDAO;
import com.app.entities.Course;
import com.app.entities.Student;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDAO studentDAO;
   
    
    
    
    @Override
    public String addStudentDetails(Student student) {
        Course course = student.getCourse();
        if (course != null) {
            double minScoreRequired = course.getMinScore();
            double studentScore = student.getScoreObtained();
            if (studentScore >= minScoreRequired) {
                studentDAO.save(student);
                return "Student added successfully!";
            } else {
                return "Admission not granted. Insufficient score. Minimum score required: " + minScoreRequired;
            }
        }
        return "Invalid course!";
    }
    

    @Override
    public String cancelStudentAdmission(Long courseId, Long studentId) {
        Student student = studentDAO.findById(studentId).orElse(null);
        if (student != null && student.getCourse().getId().equals(courseId)) {
            studentDAO.deleteById(studentId);
            return "Student admission canceled successfully!";
        }
        return "Invalid student or course!";
    }
    
    @Override
    public List<Student> getAllStudentsForCourse(String courseTitle) {
        return studentDAO.findByCourse_Title(courseTitle);
    }
}
