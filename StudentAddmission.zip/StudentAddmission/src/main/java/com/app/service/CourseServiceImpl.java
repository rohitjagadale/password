package com.app.service;

import com.app.dao.CourseDAO;
import com.app.entities.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseDAO courseDAO;

    @Override
    public String launchNewCourse(Course course) {
        courseDAO.save(course);
        return "New course launched successfully!";
    }

    @Override
    public String updateCourseFees(Long courseId, double updatedFees) {
        Course course = courseDAO.findById(courseId).orElse(null);
        if (course != null) {
            course.setFees(updatedFees);
            courseDAO.save(course);
            return "Course fees updated successfully!";
        }
        return "Course not found!";
    }
}
