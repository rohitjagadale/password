// StudentService.java
package com.app.service;

import com.app.entities.Student;

import java.util.List;

public interface StudentService {

    String addStudentDetails(Student student);

    String cancelStudentAdmission(Long courseId, Long studentId);

    List<Student> getAllStudentsForCourse(String courseTitle);
}
