package com.app.controller;

import com.app.dto.ApiResponse;
import com.app.entities.Course;
import com.app.entities.Student;
import com.app.service.CourseService;
import com.app.service.StudentService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admission")
public class AdmissionController {

    @Autowired
    private CourseService courseService;

    @Autowired
    private StudentService studentService;

    @PostMapping("/courses")
    public ApiResponse launchNewCourse(@RequestBody Course course) {
        return new ApiResponse(courseService.launchNewCourse(course));
    }

    @PostMapping("/students")
    public ApiResponse addStudentDetails(@RequestBody Student student) {
        return new ApiResponse(studentService.addStudentDetails(student));
    }

    @GetMapping("/students/course_title/{courseTitle}")
    public ApiResponse viewAllStudentsForCourse(@PathVariable String courseTitle) {
        List<Student> students = studentService.getAllStudentsForCourse(courseTitle);
        return new ApiResponse(students);
    }

    @PutMapping("/courses/{courseId}/fees/{updatedFees}")
    public ApiResponse updateCourseFees(@PathVariable Long courseId, @PathVariable double updatedFees) {
        return new ApiResponse(courseService.updateCourseFees(courseId, updatedFees));
    }

    @DeleteMapping("/courses/{courseId}/students/{studentId}")
    public ApiResponse cancelStudentAdmission(@PathVariable Long courseId, @PathVariable Long studentId) {
        return new ApiResponse(studentService.cancelStudentAdmission(courseId, studentId));
    }
}
